# Walkthrough: Фаза 5 - Оптимизация Grounding и исправление TTFT

## Цели
1. **Исправить Grounding**: Передавать только те страницы, которые LLM реально использовала для ответа.
2. **Исправить TTFT (Latency)**: Решить проблему с Latency = 0, которая давала штраф.

## Что было сделано
- **LLM Streaming**: Перешли на `.stream_complete()`. Это позволило [TelemetryTimer](file:///Users/arturkaramov/rag_challenge/starter_kit/arlc/telemetry.py#77-111) зафиксировать время первого токена и убрать "нулевую задержку".
- **LLM Attribution**: Теперь каждый чанк контекста помечен заголовком `[doc_id: ..., page_numbers: ...]`.
- **JSON Ответы**: Промпт требует JSON с полями [answer](file:///Users/arturkaramov/rag_challenge/starter_kit/arlc/submission.py#58-63) и [sources](file:///Users/arturkaramov/rag_challenge/starter_kit/examples/langchain/naive_rag_langchain.py#48-58). Это позволяет нам точно знать, на какие страницы ссылается LLM.
- **Обработка Null**: Если LLM не находит ответ, мы отправляем пустой список страниц `[]`. По правилам конкурса это дает Grounding = 1.0 для таких вопросов.

## Результаты
- **Grounding Score**: Вырос с **0.39** до **0.59** (+50% рост! 🚀).
- **TTFT (Latency)**: Исправлено. Теперь Latency = **1819ms**.
- **Multiplier**: Мы получили бонусный множитель **1.0134** (вместо штрафа 0.85).
- **Total Score**: Вырос с **0.23** до **0.36**!

## Сравнение метрик
| Метрика | Baseline | Фаза 2 | Фаза 5 |
| :--- | :--- | :--- | :--- |
| **Total Score** | 0.2349 | 0.2151 | **0.3600** |
| **Grounding** | 0.3603 | 0.3949 | **0.5894** |
| **TTFT Multiplier**| 0.85 | 0.85 | **1.0134** |
| **Deterministic** | 0.7928 | 0.6285 | 0.6285 |

**Вывод:** Мы успешно решили проблему с Grounding и задержками. Следующий шаг — вернуть `Deterministic` скор к высоким значениям (0.8+), так как сейчас модель часто отвечает `null` из-за строгости JSON-формата.
