from __future__ import annotations

import argparse
import csv
import json
import os
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from llama_index.core import Settings, StorageContext, load_index_from_storage
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.openai import OpenAI

ROOT_DIR = Path(__file__).resolve().parents[1]
STARTER_DIR = ROOT_DIR / "starter_kit"
import sys

sys.path.append(str(STARTER_DIR))

from arlc import (  # noqa: E402
    RetrievalRef,
    SubmissionAnswer,
    SubmissionBuilder,
    Telemetry,
    TelemetryTimer,
    TimingMetrics,
    UsageMetrics,
    normalize_retrieved_pages,
)


CASE_PATTERN = re.compile(r"\b([A-Z]{2,4})\s*0*([0-9]{1,4})\s*/\s*(20[0-9]{2})\b", re.IGNORECASE)
LAW_PATTERN = re.compile(r"\b(?:DIFC\s+)?Law\s+No\.?\s*([0-9]{1,3})\s*(?:of\s*(20[0-9]{2}))?\b", re.IGNORECASE)


def _approx_tokens(text: str) -> int:
    return max(1, int(len((text or "").strip()) / 4)) if (text or "").strip() else 0


def _norm_model(model: str) -> str:
    return model.split("/", 1)[1] if "/" in model else model


def _configure(model: str, embedding_model: str) -> None:
    load_dotenv(ROOT_DIR / ".env")
    api_key = (os.getenv("OPENROUTER_API_KEY") or "").strip()
    api_base = (os.getenv("OPENROUTER_API_BASE") or "https://openrouter.ai/api/v1").strip()
    if not api_key:
        raise RuntimeError("OPENROUTER_API_KEY is required.")
    Settings.llm = OpenAI(model=_norm_model(model), api_key=api_key, api_base=api_base, temperature=0.0)
    Settings.embed_model = OpenAIEmbedding(model=_norm_model(embedding_model), api_key=api_key, api_base=api_base)


def _normalize_doc_number(value: str) -> str:
    value = re.sub(r"\s+", " ", (value or "").strip()).upper()
    m = CASE_PATTERN.search(value)
    if m:
        return f"{m.group(1).upper()} {int(m.group(2)):03d}/{m.group(3)}"
    m = LAW_PATTERN.search(value)
    if m:
        if m.group(2):
            return f"LAW NO. {int(m.group(1))} OF {m.group(2)}"
        return f"LAW NO. {int(m.group(1))}"
    return value


def _extract_doc_numbers(question: str) -> list[str]:
    out: list[str] = []
    for m in CASE_PATTERN.finditer(question):
        out.append(f"{m.group(1).upper()} {int(m.group(2)):03d}/{m.group(3)}")
    for m in LAW_PATTERN.finditer(question):
        if m.group(2):
            out.append(f"LAW NO. {int(m.group(1))} OF {m.group(2)}")
        else:
            out.append(f"LAW NO. {int(m.group(1))}")
    return sorted(set(out))


def _build_doc_maps(docs_list_path: Path) -> tuple[dict[str, dict[str, str]], dict[str, list[str]]]:
    rows = list(csv.DictReader(docs_list_path.open("r", encoding="utf-8", newline="")))
    doc_by_id = {r["doc_id"]: r for r in rows}
    number_to_doc_ids: dict[str, list[str]] = {}
    for r in rows:
        normalized = _normalize_doc_number(r.get("document_number", ""))
        if not normalized:
            continue
        number_to_doc_ids.setdefault(normalized, []).append(r["doc_id"])
    return doc_by_id, number_to_doc_ids


def _direct_docs_list_answer(question: str, answer_type: str, candidate_doc_rows: list[dict[str, str]]):
    q = question.lower()
    if not candidate_doc_rows:
        return None
    row = candidate_doc_rows[0]

    if "date of issue" in q and answer_type == "date":
        return row.get("date") or None
    if ("defendant" in q and answer_type == "name") or ("who is the defendant" in q):
        return row.get("defendant") or None
    if ("claimant" in q and answer_type == "name") or ("plaintiff" in q and answer_type == "name"):
        return row.get("claimant") or None
    if "official difc law number" in q and answer_type == "number":
        law = row.get("document_number", "")
        m = re.search(r"LAW NO\.\s*([0-9]{1,3})", law.upper())
        if m:
            return float(m.group(1))
    return None


def _direct_docs_list_answer_llm(question: str, answer_type: str, candidate_doc_rows: list[dict[str, str]]):
    if not candidate_doc_rows:
        return None, TimingMetrics(ttft_ms=0, tpot_ms=0, total_time_ms=0), 0, 0

    metadata_payload = []
    for row in candidate_doc_rows[:5]:
        metadata_payload.append(
            {
                "doc_id": row.get("doc_id", ""),
                "document_number": row.get("document_number", ""),
                "date": row.get("date", ""),
                "title": row.get("title", ""),
                "type": row.get("type", ""),
                "claimant": row.get("claimant", ""),
                "defendant": row.get("defendant", ""),
            }
        )

    prompt = (
        "You answer only from provided document metadata rows.\n"
        "If answer cannot be determined from metadata, return null.\n"
        f"answer_type: {answer_type}\n"
        f"question: {question}\n\n"
        f"metadata_rows:\n{json.dumps(metadata_payload, ensure_ascii=False, indent=2)}\n\n"
        "Return only the final answer value."
    )

    timer = TelemetryTimer()
    chunks = []
    for ch in Settings.llm.stream_complete(prompt):
        timer.mark_token()
        chunks.append(ch.delta)
    response = "".join(chunks).strip()
    answer = _parse_answer(response, answer_type)
    timing = timer.finish()
    return answer, timing, _approx_tokens(prompt), _approx_tokens(response)


def _parse_answer(raw: str, answer_type: str):
    text = (raw or "").strip()
    if not text:
        return None if answer_type != "free_text" else "There is no information on this question in the provided documents."
    if text.lower() == "null":
        return None
    if answer_type == "boolean":
        low = text.lower()
        if low in {"true", "yes", "1"}:
            return True
        if low in {"false", "no", "0"}:
            return False
        return None
    if answer_type == "number":
        try:
            return float(text.replace(",", "."))
        except ValueError:
            return None
    if answer_type == "date":
        m = re.search(r"\d{4}-\d{2}-\d{2}", text)
        return m.group(0) if m else None
    if answer_type == "names":
        vals = [x.strip() for x in re.split(r"[;,]", text) if x.strip()]
        return vals if vals else None
    if answer_type == "free_text":
        return text[:280]
    return text


def _retrieval_refs(evidence: list[dict[str, Any]]) -> list[RetrievalRef]:
    refs = [RetrievalRef(doc_id=e["doc_id"], page_numbers=[int(e["page_number"])]) for e in evidence]
    return normalize_retrieved_pages(refs)


def run(
    questions_path: Path,
    docs_list_path: Path,
    indices_dir: Path,
    out_dir: Path,
    model: str,
    embedding_model: str,
    question_limit: int,
    top_k_per_doc: int,
    max_evidence_pages: int,
    run_label: str,
    direct_mode: str,
) -> None:
    _configure(model, embedding_model)
    out_dir.mkdir(parents=True, exist_ok=True)

    questions = json.loads(questions_path.read_text(encoding="utf-8"))[:question_limit]
    doc_by_id, number_to_doc_ids = _build_doc_maps(docs_list_path)

    # lazy index cache
    indices: dict[str, Any] = {}

    builder = SubmissionBuilder(
        architecture_summary=f"{run_label} regex-routed: docs_list-first ({direct_mode}) + per-document indices + constrained retrieval",
    )
    rows_out: list[dict[str, str]] = []

    for i, q in enumerate(questions, 1):
        qid = q["id"]
        question = q["question"]
        answer_type = str(q.get("answer_type", "free_text")).lower()
        print(f"[{i}/{len(questions)}] {qid}")

        doc_numbers = _extract_doc_numbers(question)
        target_doc_ids: list[str] = []
        for num in doc_numbers:
            target_doc_ids.extend(number_to_doc_ids.get(_normalize_doc_number(num), []))
        target_doc_ids = sorted(set(target_doc_ids))
        target_rows = [doc_by_id[d] for d in target_doc_ids if d in doc_by_id]

        # Route 1: direct from docs_list
        if direct_mode == "llm":
            direct, direct_timing, direct_in_toks, direct_out_toks = _direct_docs_list_answer_llm(
                question, answer_type, target_rows
            )
        else:
            direct = _direct_docs_list_answer(question, answer_type, target_rows)
            direct_timing = TimingMetrics(ttft_ms=0, tpot_ms=0, total_time_ms=0)
            direct_in_toks, direct_out_toks = 0, _approx_tokens(str(direct)) if direct is not None else 0
        if direct is not None:
            answer = direct
            refs = []
            timing = direct_timing
            input_toks, output_toks = direct_in_toks, direct_out_toks
            route_source = f"docs_list_{direct_mode}"
        else:
            # Route 2: constrained retrieval from target documents only.
            evidence = []
            if not target_doc_ids:
                # fallback: use no answer to avoid high-noise global retrieval
                answer = None if answer_type != "free_text" else "There is no information on this question in the provided documents."
                refs = []
                timing = TimingMetrics(ttft_ms=0, tpot_ms=0, total_time_ms=0)
                input_toks, output_toks = 0, _approx_tokens(str(answer))
                route_source = "fallback_no_target_docs"
            else:
                for doc_id in target_doc_ids:
                    persist = indices_dir / doc_id
                    if not persist.exists():
                        continue
                    if doc_id not in indices:
                        storage = StorageContext.from_defaults(persist_dir=str(persist))
                        indices[doc_id] = load_index_from_storage(storage)
                    retriever = indices[doc_id].as_retriever(similarity_top_k=top_k_per_doc)
                    nodes = retriever.retrieve(question)
                    for n in nodes:
                        md = n.metadata or {}
                        evidence.append(
                            {
                                "doc_id": md.get("doc_id", doc_id),
                                "page_number": int(md.get("page_number", 0) or 0),
                                "text": n.text,
                                "score": float(getattr(n, "score", 0.0) or 0.0),
                            }
                        )
                evidence = [e for e in evidence if e["page_number"] > 0]
                evidence.sort(key=lambda x: x["score"], reverse=True)
                evidence = evidence[:max_evidence_pages]

                if not evidence:
                    answer = None if answer_type != "free_text" else "There is no information on this question in the provided documents."
                    refs = []
                    timing = TimingMetrics(ttft_ms=0, tpot_ms=0, total_time_ms=0)
                    input_toks, output_toks = 0, _approx_tokens(str(answer))
                    route_source = "fallback_no_evidence"
                else:
                    context = "\n\n".join(
                        f"[doc:{e['doc_id']} page:{e['page_number']}]\n{e['text'][:2200]}" for e in evidence
                    )
                    prompt = (
                        "Answer using only the context.\n"
                        f"Question: {question}\n"
                        f"Answer type: {answer_type}\n"
                        "If missing, return null for deterministic types.\n\n"
                        f"Context:\n{context}\n\nAnswer:"
                    )
                    timer = TelemetryTimer()
                    chunks = []
                    for ch in Settings.llm.stream_complete(prompt):
                        timer.mark_token()
                        chunks.append(ch.delta)
                    response = "".join(chunks).strip()
                    answer = _parse_answer(response, answer_type)
                    refs = _retrieval_refs(evidence)
                    timing = timer.finish()
                    input_toks, output_toks = _approx_tokens(prompt), _approx_tokens(response)
                    route_source = "retrieval"

        telemetry = Telemetry(
            timing=TimingMetrics(ttft_ms=timing.ttft_ms, tpot_ms=timing.tpot_ms, total_time_ms=timing.total_time_ms),
            retrieval=refs,
            usage=UsageMetrics(input_tokens=input_toks, output_tokens=output_toks),
            model_name=model,
        )
        builder.add_answer(SubmissionAnswer(question_id=qid, answer=answer, telemetry=telemetry))

        rows_out.append(
            {
                "question_id": qid,
                "answer_type": answer_type,
                "question": question,
                f"{run_label}.answer": json.dumps(answer, ensure_ascii=False),
                f"{run_label}.retrieval": json.dumps(
                    [{"doc_id": r.doc_id, "page_numbers": r.page_numbers} for r in refs], ensure_ascii=False
                ),
                "routed_doc_ids": ";".join(target_doc_ids),
                "routed_doc_numbers": ";".join(doc_numbers),
                "route_source": route_source,
            }
        )

    submission_path = builder.save(str(out_dir / "submission.json"))
    with (out_dir / "submission.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows_out[0].keys()) if rows_out else [])
        if rows_out:
            writer.writeheader()
            writer.writerows(rows_out)

    with zipfile.ZipFile(out_dir / "code_archive.zip", "w", zipfile.ZIP_DEFLATED) as zf:
        for p in [
            ROOT_DIR / "scripts" / "build_docs_list.py",
            ROOT_DIR / "scripts" / "build_document_indices.py",
            ROOT_DIR / "scripts" / "run_rag_routed_regex.py",
        ]:
            zf.write(p, arcname=p.relative_to(ROOT_DIR))
    print(f"saved: {submission_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run routed RAG using regex docs_list and per-doc indices.")
    parser.add_argument("--questions", default="cache/warmup/questions.json")
    parser.add_argument("--docs-list", default="artifacts/docs_list/v1_regex/docs_list.csv")
    parser.add_argument("--indices-dir", default="artifacts/document_indices/v1_regex_small")
    parser.add_argument("--out-dir", default="experiments/v4")
    parser.add_argument("--model", default="openai/gpt-4o-mini")
    parser.add_argument("--embedding-model", default="openai/text-embedding-3-small")
    parser.add_argument("--question-limit", type=int, default=25)
    parser.add_argument("--top-k-per-doc", type=int, default=3)
    parser.add_argument("--max-evidence-pages", type=int, default=3)
    parser.add_argument("--run-label", default="v4")
    parser.add_argument("--direct-mode", choices=["rules", "llm"], default="rules")
    args = parser.parse_args()

    run(
        questions_path=Path(args.questions).resolve(),
        docs_list_path=Path(args.docs_list).resolve(),
        indices_dir=Path(args.indices_dir).resolve(),
        out_dir=Path(args.out_dir).resolve(),
        model=args.model,
        embedding_model=args.embedding_model,
        question_limit=args.question_limit,
        top_k_per_doc=args.top_k_per_doc,
        max_evidence_pages=args.max_evidence_pages,
        run_label=args.run_label,
        direct_mode=args.direct_mode,
    )


if __name__ == "__main__":
    main()
